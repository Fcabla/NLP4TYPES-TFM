#' \packageDescription{koRpus.lang.en}
#'
#' The DESCRIPTION file:
#' \tabular{ll}{
#' Package: \tab koRpus.lang.en\cr
#' Type: \tab Package\cr
#' Version: \tab 0.1-4\cr
#' Date: \tab 2020-10-24\cr
#' Depends: \tab R (>= 3.1),koRpus (>= 0.11-2)\cr
#' Encoding: \tab UTF-8\cr
#' License: \tab GPL (>= 3)\cr
#' LazyLoad: \tab yes\cr
#' URL: \tab https://reaktanz.de/?c=hacking&s=koRpus\cr
#' }
#'
#' @title
#' \packageTitle{koRpus.lang.en}
#' @author
#' \packageAuthor{koRpus.lang.en}
#'
#' Maintainer: \packageMaintainer{koRpus.lang.en}
"_PACKAGE"
