testthat::context("as_rdf")

## tests coming, see vignettes

