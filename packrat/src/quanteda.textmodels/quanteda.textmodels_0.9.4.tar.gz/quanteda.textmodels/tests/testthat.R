library("testthat")
library("quanteda")
library("quanteda.textmodels")

test_check("quanteda.textmodels")
