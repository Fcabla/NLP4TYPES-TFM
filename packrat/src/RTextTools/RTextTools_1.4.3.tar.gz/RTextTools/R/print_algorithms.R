print_algorithms <- function() {
	algorithms <- c("BAGGING", "BOOSTING", "GLMNET", "NNET", "RF", "SLDA", "SVM", "TREE")
	print(algorithms)
}