library(testthat)
library(groupdata2)

test_check("groupdata2")
