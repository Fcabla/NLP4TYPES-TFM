# the tests are realized using the "testthat" package
# and can be found in ./tests

library(testthat)
library(sylly)

test_check("sylly")
