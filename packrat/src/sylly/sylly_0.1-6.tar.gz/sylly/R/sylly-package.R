#' \packageDescription{sylly}
#'
#' The DESCRIPTION file:
#' \tabular{ll}{
#' Package: \tab sylly\cr
#' Type: \tab Package\cr
#' Version: \tab 0.1-6\cr
#' Date: \tab 2020-09-19\cr
#' Depends: \tab R (>= 3.0.0)\cr
#' Encoding: \tab UTF-8\cr
#' License: \tab GPL (>= 3)\cr
#' LazyLoad: \tab yes\cr
#' URL: \tab https://reaktanz.de/?c=hacking&s=sylly\cr
#' }
#'
#' @title
#' \packageTitle{sylly}
#' @author
#' \packageAuthor{sylly}
#'
#' Maintainer: \packageMaintainer{sylly}
"_PACKAGE"
