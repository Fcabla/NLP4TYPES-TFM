# quanteda.classifiers 0.4

* Fixed a performance issue in `crossval()`; now it's much improved in speed.
* Added a `NEWS.md` file to track changes to the package.
