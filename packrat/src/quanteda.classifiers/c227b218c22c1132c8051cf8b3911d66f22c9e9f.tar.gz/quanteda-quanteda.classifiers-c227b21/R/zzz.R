.onAttach <- function(...) {
    options(keras.fit_verbose = 0)
    options(keras.view_metrics = FALSE)
}

