The text in file "sample_text.txt" is a sample from the article on "Phasmatodea", taken from the english Wikipedia:
 o http://en.wikipedia.org/wiki/Phasmatodea#Defense_mechanisms

It is  available under the Creative Commons Attribution-ShareAlike License:
 o http://creativecommons.org/licenses/by-sa/3.0/

Additional terms may apply. See Terms of use for details:
 o http://wikimediafoundation.org/wiki/Terms_of_use
