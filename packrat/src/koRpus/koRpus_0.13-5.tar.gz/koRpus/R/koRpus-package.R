#' \packageDescription{koRpus}
#'
#' The DESCRIPTION file:
#' \tabular{ll}{
#' Package: \tab koRpus\cr
#' Type: \tab Package\cr
#' Version: \tab 0.13-5\cr
#' Date: \tab 2021-02-02\cr
#' Depends: \tab R (>= 3.0.0),sylly (>= 0.1-6)\cr
#' Enhances: \tab rkward\cr
#' Encoding: \tab UTF-8\cr
#' License: \tab GPL (>= 3)\cr
#' LazyLoad: \tab yes\cr
#' URL: \tab https://reaktanz.de/?c=hacking&s=koRpus\cr
#' }
#'
#' @title
#' \packageTitle{koRpus}
#' @author
#' \packageAuthor{koRpus}
#'
#' Maintainer: \packageMaintainer{koRpus}
"_PACKAGE"
